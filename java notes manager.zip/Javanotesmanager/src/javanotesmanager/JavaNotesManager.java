package javanotesmanager;

import java.io.*;
import java.util.Scanner;

public class JavaNotesManager {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String file1 = "JavaFile1.txt";
        String file2 = "JavaFile2.txt";

        try {
            // Step 1: Create JavaFile1.txt with input from console
            System.out.println("Enter text for JavaFile1.txt:");
            String[] file1Content = {
                    "Java is an object-oriented programming language.",
                    "It supports encapsulation, inheritance, and polymorphism.",
                    "File handling in Java allows for efficient reading and searching of text.",
                    "Keep learning and mastering Java!"
            };

            BufferedWriter writer1 = new BufferedWriter(new FileWriter(file1));
            for (String line : file1Content) {
                writer1.write(line);
                writer1.newLine();
            }
            writer1.close();
            System.out.println("JavaFile1.txt created successfully.\n");

            // Step 2: Display contents of JavaFile1.txt
            System.out.println("Contents of JavaFile1.txt:");
            BufferedReader reader1 = new BufferedReader(new FileReader(file1));
            String line;
            while ((line = reader1.readLine()) != null) {
                System.out.println(line);
            }
            reader1.close();
            System.out.println();

            // Step 3: Create JavaFile2.txt with one line from console
            System.out.println("Enter a line for JavaFile2.txt:");
            String inputLine = "This is the first line in this JavaFile2.txt file."; // or get from sc.nextLine()

            BufferedWriter writer2 = new BufferedWriter(new FileWriter(file2));
            writer2.write(inputLine);
            writer2.newLine();
            writer2.close();
            System.out.println("JavaFile2.txt created with first line.\n");

            // Step 4: Copy contents of JavaFile1.txt to JavaFile2.txt using file streams
            FileInputStream fin = new FileInputStream(file1);
            FileOutputStream fout = new FileOutputStream(file2, true); // append mode

            fout.write('\n'); // separate old content

            int ch;
            while ((ch = fin.read()) != -1) {
                fout.write(ch);
            }
            fin.close();
            fout.close();
            System.out.println("Contents of JavaFile1.txt copied to JavaFile2.txt.\n");

            // Step 5: Analyze JavaFile1.txt
            int charCount = 0, wordCount = 0, lineCount = 0;
            String searchWord = "polymorphism";
            int wordOccurrence = 0;
            int lineNumber = 0;

            System.out.println("Analyzing JavaFile1.txt...");

            BufferedReader analyzeReader = new BufferedReader(new FileReader("JavaFile1.txt"));
            String analyzeLine;

            while ((analyzeLine = analyzeReader.readLine()) != null) {
                lineNumber++;
                lineCount++;
                charCount += analyzeLine.length();

                String[] words = analyzeLine.split("\\s+");
                boolean foundInLine = false;

                for (String word : words) {
                    // Clean punctuation and make lowercase
                    word = word.replaceAll("[^a-zA-Z]", "").toLowerCase();

                    if (word.equals(searchWord.toLowerCase())) {
                        wordOccurrence++;
                        foundInLine = true;
                    }
                }

                if (foundInLine) {
                    System.out.println("Word '" + searchWord + "' found at line: " + lineNumber);
                }
            }
            analyzeReader.close();

            // Step 6: Display analysis results
            System.out.println("\n--- Analysis of JavaFile1.txt ---");
            System.out.println("Total Characters: " + charCount);
            System.out.println("Total Words: " + wordCount);
            System.out.println("Total Lines: " + lineCount);
            System.out.println("Total Occurrences of 'polymorphism': " + wordOccurrence);

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        sc.close();
    }
}
