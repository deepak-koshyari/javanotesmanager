/**
 * 
 */
/**
 * 
 */
module Javanotesmanager {
}